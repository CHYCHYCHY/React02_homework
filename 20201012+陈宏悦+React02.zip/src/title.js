import React, { Component } from "react";

export default class Title extends Component {
    render() {
        return <h2 className="title">留言板</h2>
    }
}